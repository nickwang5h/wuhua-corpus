import type { TextBook } from '../src/types.js';
export declare function readBook(id: string): Promise<TextBook>;
