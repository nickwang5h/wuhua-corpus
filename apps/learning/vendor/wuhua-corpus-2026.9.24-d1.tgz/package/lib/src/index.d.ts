import manifest from './manifest.json';
import type { TextBook, Reference, Paragraph, Chapter, Transition } from './types.js';
import works from './works.json';
export { works };
export declare const concepts: Record<string, {
    id: string;
}>;
export { manifest };
export declare const contentRelease = "2026-09-24-d1";
export declare function loadBook(id: string): Promise<TextBook>;
export declare function workForId(id: string): string | undefined;
export declare function findReference(book: TextBook, id: string): {
    chapter: Chapter;
    paragraph: Paragraph;
    ref: Reference;
} | undefined;
export declare const transitions: Transition[];
export declare const historicalReferences: Reference[];
export declare function historicalReference(id: string, version?: string): Reference | undefined;
export declare function successors(ref: Pick<Reference, 'id' | 'version'>, changes?: Transition[]): Transition | undefined;
