export type Review = {
    status: 'draft' | 'reviewed' | 'published' | 'withdrawn';
    author: string;
    reviewer?: string;
    reviewedAt?: string;
    textVersion?: string;
};
export type Reference = {
    id: string;
    version: string;
    text: string;
    title: string;
    source: string;
    start?: number;
    end?: number;
};
export type Alias = {
    id: string;
    version: string;
    text: string;
    start: number;
    end: number;
};
export type Paragraph = {
    id: string;
    version: string;
    text: string;
    sourceText?: string;
    correction?: {
        reason: string;
        review: Review;
    };
    aliases: Alias[];
};
export type Chapter = {
    id: string;
    number: number;
    title: string;
    source: string;
    paragraphs: Paragraph[];
};
export type TextBook = {
    id: string;
    chapters: Chapter[];
};
export type Transition = {
    from: {
        id: string;
        version: string;
    };
    kind: 'revision' | 'split' | 'merge' | 'withdrawn';
    reason: string;
    targets: {
        id: string;
        version: string;
        start?: number;
        end?: number;
    }[];
};
export type PinyinToken = {
    start: number;
    end: number;
    text: string;
    pinyin: string;
};
export type Aid = {
    id: string;
    target: string;
    version: string;
    kind: 'pinyin' | 'translation-en' | 'culture-en' | 'adaptation-zh' | 'vocabulary-en' | 'explanation-zh' | 'commentary-zh';
    review: Review;
    start?: number;
    end?: number;
    text?: string;
    tokens?: PinyinToken[];
    rights: {
        author: string;
        license: string;
        source?: string;
        edition?: string;
        note?: string;
    };
};
