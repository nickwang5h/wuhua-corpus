import type { TextBook, Aid, Reference, Transition } from './types.js';
export declare function validateBooks(books: TextBook[]): Set<string>;
export declare function validateHistory(records: Reference[], transitions: Transition[], current: Reference[]): void;
export declare function validateAids(aids: Aid[], books: TextBook[]): void;
