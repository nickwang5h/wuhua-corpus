import type { Aid } from './types.js';
export declare const pinyinAids: Aid[];
export declare function pinyinFor(id: string, version: string): Aid | undefined;
