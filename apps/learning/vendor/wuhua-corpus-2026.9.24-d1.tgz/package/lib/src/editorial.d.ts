import type { Aid } from './types.js';
export declare const editorialAids: Aid[];
export declare function editorialFor(id: string, version: string): Aid[];
